package cit.edu.wrdmstr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WrdmstrApplication {

	public static void main(String[] args) {
		SpringApplication.run(WrdmstrApplication.class, args);
	}

}
